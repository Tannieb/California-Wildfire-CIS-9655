import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import dash
from dash import dcc, html, Input, Output, State, dash_table
import dash_bootstrap_components as dbc

data_df = pd.read_excel('Top_20_Most_Destructive_Fire.xlsx')
data_df['Date'] = pd.to_datetime(data_df['Date'])
data_df['Month'] = data_df['Date'].dt.month
data_df['Year'] = data_df['Date'].dt.year
data_df['Combined Impact'] = data_df['Acres'] + data_df['Structures'] + data_df['Deaths']

years = sorted(data_df['Year'].dropna().unique())
causes = sorted(data_df['Cause'].dropna().unique())
fires = sorted(data_df['Fire Name'].dropna().unique())

app = dash.Dash(__name__, external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = dbc.Container([
    html.H1("California Wildfires Dashboard", className='text-center mb-4'),
    dbc.Row([
        dbc.Col(dcc.Dropdown(id='year-dropdown',
                             options=[{'label': str(y), 'value': y} for y in years],
                             multi=True, placeholder="Select Year(s)"), width=4),
        dbc.Col(dcc.Dropdown(id='cause-dropdown',
                             options=[{'label': c, 'value': c} for c in causes],
                             multi=True, placeholder="Select Cause(s)"), width=4),
        dbc.Col(dcc.Dropdown(id='fire-dropdown',
                             options=[{'label': f, 'value': f} for f in fires],
                             multi=True, placeholder="Select Fire Name(s)"), width=4),
    ], className='mb-4'),
    dbc.Tabs([
        dbc.Tab(label='Overview', tab_id='overview'),
        dbc.Tab(label='Fire Impacts', tab_id='impacts'),
        dbc.Tab(label='Causes', tab_id='causes'),
        dbc.Tab(label='Ratings', tab_id='ratings'),
        dbc.Tab(label='Bubble & Streamgraphs', tab_id='bubble_stream'),
        dbc.Tab(label='Data Table', tab_id='data_table'),
    ], id='tabs', active_tab='overview', className='mb-3'),
    html.Div(id='tab-content')
], fluid=True)

@app.callback(
    Output('tab-content', 'children'),
    Input('tabs', 'active_tab'),
    Input('year-dropdown', 'value'),
    Input('cause-dropdown', 'value'),
    Input('fire-dropdown', 'value')
)
def render_tab(tab, years, causes, fires):
    df = data_df.copy()
    if years: df = df[df['Year'].isin(years)]
    if causes: df = df[df['Cause'].isin(causes)]
    if fires: df = df[df['Fire Name'].isin(fires)]

    if tab == 'overview':
        return dbc.Row([
            dbc.Col(dcc.Graph(figure=px.line(df.groupby('Date').sum(numeric_only=True).reset_index(), x='Date', y='Acres', title='Acres Burned Over Time')), width=12),
            dbc.Col(dcc.Graph(figure=px.bar(df.groupby('Month').count().reset_index(), x='Month', y='Fire Name', title='Fires by Month')), width=6),
            dbc.Col(dcc.Graph(figure=px.bar(df.groupby('Year').count().reset_index(), x='Year', y='Fire Name', title='Fires by Year')), width=6)
        ])
    elif tab == 'impacts':
        return dcc.Graph(figure=px.bar(df.groupby('Fire Name').sum(numeric_only=True).reset_index(), x='Fire Name', y=['Acres', 'Structures', 'Deaths'], title='Fire Impacts'))
    elif tab == 'causes':
        return dbc.Row([
            dbc.Col(dcc.Graph(figure=px.bar(df.groupby('Cause').count().reset_index(), x='Cause', y='Fire Name', title='Fire Cause Frequency')), width=6),
            dbc.Col(dcc.Graph(figure=px.bar(df.groupby('Cause').mean(numeric_only=True).reset_index(), x='Cause', y=['Acres', 'Structures', 'Deaths'], title='Avg Impact by Cause')), width=6)
        ])
    elif tab == 'ratings':
        return dbc.Row([
            dbc.Col(dcc.Graph(figure=px.bar(df, x='Fire Name', y='Acres', color='Rating', title='Acres by Rating')), width=12),
            dbc.Col(dcc.Graph(figure=px.bar(df, x='Fire Name', y='Structures', color='Rating', title='Structures by Rating')), width=6),
            dbc.Col(dcc.Graph(figure=px.bar(df, x='Fire Name', y='Deaths', color='Rating', title='Deaths by Rating')), width=6)
        ])
    elif tab == 'bubble_stream':
        bubble = px.scatter(df.groupby('Fire Name')[['Acres', 'Structures', 'Deaths']].sum().reset_index(), x='Structures', y='Deaths', size='Acres', color='Fire Name', title='Fire Bubble Chart')
        stream = go.Figure()
        for fire in df['Fire Name'].unique():
            fire_df = df[df['Fire Name'] == fire].groupby('Date')['Acres'].sum().reset_index()
            stream.add_trace(go.Scatter(x=fire_df['Date'], y=fire_df['Acres'], mode='lines', stackgroup='one', name=fire))
        stream.update_layout(title='Streamgraph of Acres Burned')
        return dbc.Row([dbc.Col(dcc.Graph(figure=bubble), width=6), dbc.Col(dcc.Graph(figure=stream), width=6)])
    elif tab == 'data_table':
        return dash_table.DataTable(
            data=df.to_dict('records'),
            columns=[{"name": i, "id": i} for i in df.columns],
            page_size=10,
            filter_action='native',
            sort_action='native',
            style_table={'overflowX': 'auto'}
        )
    return html.Div("404")

if __name__ == '__main__':
    app.run_server(debug=True)
